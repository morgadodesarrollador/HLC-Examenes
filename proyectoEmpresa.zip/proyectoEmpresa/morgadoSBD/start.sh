#!/bin/bash
set -e

...
/etc/init.d/ssh start
tail -f /dev/null



